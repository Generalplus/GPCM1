/**************************************************************************************************
 * Copyright(c) 2019 GENERALPLUS Technology Corporation. All rights reserved.
 *-------------------------------------------------------------------------------------------------
 * @File:
 *   main.c
 * @Version:
 *
 * @Date:
 *
 * @Abstract:
 *
 **************************************************************************************************/


/*---------------------------------------------------------------------------------------
 * Header File Included Area
 *---------------------------------------------------------------------------------------*/
#include "GPCM1Fx.h"
#include "KeyScan.h"
#include "glibc_wrapper.h"


/*---------------------------------------------------------------------------------------
 * Gobal Variable Declaration Area
 *---------------------------------------------------------------------------------------*/
#if defined(__CC_ARM)
__align(4) KEYSCAN_WORKING_RAM KeyScanWorkingRam;
#elif defined(__GNUC__)
__attribute__ ((aligned (4))) KEYSCAN_WORKING_RAM KeyScanWorkingRam;
#endif 

uint32_t ScanedKey;
uint8_t ReadDataTemp;
uint8_t WriteDataTemp = 0;
uint8_t WriteDataBuf1[16] = {0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6, 0xA7, 0xA8, 0xA9, 0xAA, 0xAB, 0xAC, 0xAD, 0xAE, 0xAF};
uint8_t WriteDataBuf2[16] = {0xCF, 0xCE, 0xCD, 0xCC, 0xCB, 0xCA, 0xC9, 0xC8, 0xC7, 0xC6, 0xC5, 0xC4, 0xC3, 0xC2, 0xC1, 0xC0};
uint8_t ReadDataBuf[16];


/*---------------------------------------------------------------------------------------
 * Subroutine Area
 *---------------------------------------------------------------------------------------*/

/** 
 * @brief  
 *         
 * @param 
 *   DataAddr [in]:
 *   WriteData [in]: 
 * @return 
 *   None.
 */
void EEPROM_WriteByte(uint8_t DataAddr, uint8_t WriteData)
{
  I2C_Master_StartAndAddr(0x00A0, I2C_WRITE);
  I2C_Master_SendByte(DataAddr);        
  I2C_Master_SendByte(WriteData);	  
  I2C_Master_Stop();	
}

/** 
 * @brief  
 *         
 * @param 
 *   DataAddr [in]:
 *  *pSrcBuf [in]: Source buffer address
 *   DataLen [in]: Data length (Byte)
 * @return 
 *   None.
 */
void EEPROM_WriteNBytes(uint8_t DataAddr, uint8_t *SrcBuffer, uint32_t DataLen)
{
 uint32_t iCount;
	
	I2C_Master_StartAndAddr(0x00A0, I2C_WRITE);
  I2C_Master_SendByte(DataAddr);
	for(iCount = 0; iCount < DataLen; iCount++)
	{
		I2C_Master_SendByte(SrcBuffer[iCount]);
	}  
  I2C_Master_Stop();	
}

/** 
 * @brief  
 *         
 * @param 
 *   DataAddr [in]:
 *  *pSrcBuf [in]: Source buffer address
 *   DataLen [in]: Data length (Byte)
 * @return 
 *   None.
 */
void EEPROM_WriteNBytes_DMA(uint8_t DataAddr, uint8_t *pSrcBuf, uint32_t DataLen)
{
	DMA_Init(DMA2, DMA_REQSEL_I2C, DMA_SRC_DATA_8B, DMA_SRC_ADDR_INC, DMA_DST_DATA_8B, DMA_DST_ADDR_FIX);
	DMA_Trigger(DMA2, (uint32_t)pSrcBuf, (uint32_t)&I2C->DATA, DataLen);
	I2C_Master_StartAndAddr(0x00A0, I2C_WRITE);
  I2C_Master_SendByte(DataAddr);
  while(DMA_CheckBusy(DMA2) != 0);
	DMA_Close(DMA2);
	while(I2C_CheckBusy() != 0);
  I2C_Master_Stop();	
}

/** 
 * @brief  
 *         
 * @param 
 *   DataAddr [in]:
 * @return 
 *   A byte data
 */
uint8_t EEPROM_ReadByte(uint8_t DataAddr)
{
	uint8_t DataTemp;
	
  I2C_Master_StartAndAddr(0x00A0, I2C_WRITE);	
  I2C_Master_SendByte(DataAddr);		
  I2C_Master_StartAndAddr(0x00A0, I2C_READ);
	I2C_Master_ReadByteTrigger();
  DataTemp = I2C_Master_ReadByteNack();	
  I2C_Master_Stop();	

  return DataTemp; 	
}

/** 
 * @brief  
 *         
 * @param 
 *   DataAddr [in]:
 *  *pDstBuf [out]: Destination buffer address
 *   DataLen [in]: Data length (Byte)
 * @return 
 *   A byte data
 */
void EEPROM_ReadNBytes(uint8_t DataAddr, uint8_t *pDstBuf, uint32_t DataLen)
{
	uint32_t iCount;
	
  I2C_Master_StartAndAddr(0x00A0, I2C_WRITE);	
  I2C_Master_SendByte(DataAddr);		
  I2C_Master_StartAndAddr(0x00A0, I2C_READ);
	I2C_Master_ReadByteTrigger();

	for(iCount = 0; iCount < (DataLen - 1); iCount++)
	{
		pDstBuf[iCount] = I2C_Master_ReadByteAck();
	}  		
	
	pDstBuf[iCount] = I2C_Master_ReadByteNack();  
  I2C_Master_Stop();	  
}

/** 
 * @brief  
 *         
 * @param 
 *   DataAddr [in]:
 *  *pDstBuf [out]: Destination buffer address
 *   DataLen [in]: Data length (Byte)
 * @return 
 *   A byte data
 */
void EEPROM_ReadNBytes_DMA(uint8_t DataAddr, uint8_t *pDstBuf, uint32_t DataLen)
{		
	I2C_Master_StartAndAddr(0x00A0, I2C_WRITE);	
  I2C_Master_SendByte(DataAddr);		
  I2C_Master_StartAndAddr(0x00A0, I2C_READ);		
  DMA_Init(DMA2, DMA_REQSEL_I2C, DMA_SRC_DATA_8B, DMA_SRC_ADDR_FIX, DMA_DST_DATA_8B, DMA_DST_ADDR_INC);
	DMA_Trigger(DMA2, (uint32_t)&I2C->DATA, (uint32_t)pDstBuf, DataLen);		
	I2C_Master_ReadByteTrigger();
  while(DMA_CheckBusy(DMA2) != 0);
	DMA_Close(DMA2);
	while(I2C_CheckBusy() != 0);
  I2C_Master_Stop();	  
}


/*---------------------------------------------------------------------------------------
 * Main Function
 *---------------------------------------------------------------------------------------*/
int main(void)
{	
  SystemInit();
		
	KeyScan_Initial(&KeyScanWorkingRam);                               // key scan init.
	
	/*
	 * Init I2C I/F
	 */	
	I2C_Master_Init(I2C_IOA15_16);
	I2C_SetClkDiv(I2C_CLK_SEL_HCLK_DIV_1024);
	
  while(1)
	{
		WDT_Clear();
		
		KeyScan_ServiceLoop();
		ScanedKey = KeyScan_GetCh();
	  switch(ScanedKey)
		{
		  case 0x01:                                                     // IOA0+VDD: Init I2C I/F
	      I2C_Master_Init(I2C_IOA15_16);
	      I2C_SetClkDiv(I2C_CLK_SEL_HCLK_DIV_1024);	      
        break;	
			
		  case 0x02:                                                     // IOA1+VDD: Close I2C I/F
	      I2C_Close();
        break;			
			
		  case 0x04:                                                     // IOA2+VDD: Write a byte to EEPROM
	      EEPROM_WriteByte(0x10, WriteDataTemp++);
        break;
			
			case 0x08:                                                     // IOA3+VDD: Read a byte from EEPROM
        ReadDataTemp = EEPROM_ReadByte(0x10);
				break;

		  case 0x10:                                                     // IOA4+VDD: Write N bytes to EEPROM
	      EEPROM_WriteNBytes(0x20, WriteDataBuf1, sizeof(WriteDataBuf1));
        break;		

		  case 0x20:                                                     // IOA5+VDD: Read N bytes from EEPROM
	      EEPROM_ReadNBytes(0x20, ReadDataBuf, sizeof(ReadDataBuf));
        break;	

		  case 0x40:                                                     // IOA6+VDD: Write N bytes to EEPROM
	      EEPROM_WriteNBytes_DMA(0x20, WriteDataBuf2, sizeof(WriteDataBuf2));
        break;		

		  case 0x80:                                                     // IOA7+VDD: Read N bytes from EEPROM
	      EEPROM_ReadNBytes_DMA(0x20, ReadDataBuf, sizeof(ReadDataBuf));
        break;				
		}			
	}		
}

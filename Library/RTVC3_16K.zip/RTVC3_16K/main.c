/**************************************************************************************************
 * Copyright(c) 2019 GENERALPLUS Technology Corporation. All rights reserved.
 *-------------------------------------------------------------------------------------------------
 * @File:
 *   main.c
 * @Version:
 *
 * @Date:
 *
 * @Abstract:
 *
 **************************************************************************************************/


/*---------------------------------------------------------------------------------------
 * Header File Included Area
 *---------------------------------------------------------------------------------------*/
#include "GPCM1Fx.h"
#include "SACM_VC3_User.h"
#include "APP_SwVolumeControl.h"
#include "KeyScan.h"
#include "glibc_wrapper.h"


/*---------------------------------------------------------------------------------------
 * Gobal Variable Declaration Area
 *---------------------------------------------------------------------------------------*/
#if defined(__CC_ARM)
__align(4) SACM_VC3_API_WORKING_RAM Vc3ApiWorkingRam;
__align(4) SACM_VC3_PCM_BUFFER Vc3PcmBuffer;
__align(4) SACM_VC3_KERNEL_RAM Vc3KernelWorkingRam;
__align(4) SACM_VC3_KERNEL_RAM Vc3KernelWorkingRam2;
__align(4) SACM_VC3_VM_KERNEL_RAM Vc3VmKernelWorkingRam;
__align(4) KEYSCAN_WORKING_RAM KeyScanWorkingRam;
#elif defined(__GNUC__)
__attribute__ ((aligned (4))) SACM_VC3_API_WORKING_RAM Vc3ApiWorkingRam;
__attribute__ ((aligned (4))) SACM_VC3_PCM_BUFFER Vc3PcmBuffer;
__attribute__ ((aligned (4))) SACM_VC3_KERNEL_RAM Vc3KernelWorkingRam;
__attribute__ ((aligned (4))) SACM_VC3_KERNEL_RAM Vc3KernelWorkingRam2;
__attribute__ ((aligned (4))) SACM_VC3_VM_KERNEL_RAM Vc3VmKernelWorkingRam;
__attribute__ ((aligned (4))) KEYSCAN_WORKING_RAM KeyScanWorkingRam;
#endif

int8_t Vc3Mode = VC3_SHIFT_PITCH_MODE;
int8_t Vc3ShiftPitch = 10;
int8_t Vc3ConstPitch = 0;
int8_t Vc3EchoGain = 6;
int8_t Vc3PlayEn = 1;
uint32_t ScanedKey;
int8_t SwVolGain = 5;


/*---------------------------------------------------------------------------------------
 * Main Function
 *---------------------------------------------------------------------------------------*/
int main(void)
{
  SystemInit();

	KeyScan_Initial(&KeyScanWorkingRam);           // key scan init
  APP_SwVolCtrl_Init();                          // Software volume control init.
	APP_SwVolCtrl_SetVolGain(0, SwVolGain);

	SACM_VC3_Initial(&Vc3ApiWorkingRam, &Vc3PcmBuffer);
	SACM_VC3_Mode(Vc3Mode, &Vc3KernelWorkingRam);
	SACM_VC3_ShiftPitchMode_SetPitch(Vc3ShiftPitch);
	SACM_VC3_Play(VC3_DAC_CH0, VC3_AUTO_RAMP_UP + VC3_AUTO_RAMP_DOWN);

  while(1)
	{
		WDT_Clear();
		SACM_VC3_ServiceLoop();
		KeyScan_ServiceLoop();

		if(SACM_VC3_CheckCpuOverload() != 0)
		{
			SACM_VC3_ClearCpuOverload();
		}

		ScanedKey = KeyScan_GetCh();
	  switch(ScanedKey)
		{
			case 0x01:                                 // VC3 play/stop
				if(Vc3PlayEn == 0)
				{
					Vc3PlayEn = 1;
			    SACM_VC3_Play(VC3_DAC_CH0, VC3_AUTO_RAMP_UP + VC3_AUTO_RAMP_DOWN);
				}
				else
				{
					Vc3PlayEn = 0;
				  SACM_VC3_Stop();
				}
				break;

			case 0x02:                                 // VC3 effect parameter up
				switch(Vc3Mode)
				{
					case VC3_SHIFT_PITCH_MODE:
				    Vc3ShiftPitch++;
			      if(Vc3ShiftPitch >= MAX_VC3_SHIFT_PITCH_LIMIT)
				    {
					    Vc3ShiftPitch = MAX_VC3_SHIFT_PITCH_LIMIT;
				    }
            SACM_VC3_ShiftPitchMode_SetPitch(Vc3ShiftPitch);
						break;

					case VC3_CONST_PITCH_MODE:
				    Vc3ConstPitch++;
			      if(Vc3ConstPitch >= MAX_VC3_CONST_PITCH_LIMIT)
				    {
					    Vc3ConstPitch = MAX_VC3_CONST_PITCH_LIMIT;
				    }
						SACM_VC3_ConstPitchMode_SetPitch(Vc3ConstPitch);
						break;

					case VC3_ECHO_MODE:
				    Vc3EchoGain++;
			      if(Vc3EchoGain >= MAX_VC3_ECHO_GAIN_LIMIT)
				    {
					    Vc3EchoGain = MAX_VC3_ECHO_GAIN_LIMIT;
				    }
            SACM_VC3_EchoMode_SetGain(Vc3EchoGain);
						break;
				}
			  break;

			case 0x04:                                 // VC3 effect parameter down
				switch(Vc3Mode)
				{
					case VC3_SHIFT_PITCH_MODE:
				    Vc3ShiftPitch--;
			      if(Vc3ShiftPitch <= MIN_VC3_SHIFT_PITCH_LIMIT)
				    {
					    Vc3ShiftPitch = MIN_VC3_SHIFT_PITCH_LIMIT;
				    }
            SACM_VC3_ShiftPitchMode_SetPitch(Vc3ShiftPitch);
						break;

					case VC3_CONST_PITCH_MODE:
				    Vc3ConstPitch--;
			      if(Vc3ConstPitch <= MIN_VC3_CONST_PITCH_LIMIT)
				    {
					    Vc3ConstPitch = MIN_VC3_CONST_PITCH_LIMIT;
				    }
            SACM_VC3_ConstPitchMode_SetPitch(Vc3ConstPitch);
						break;

					case VC3_ECHO_MODE:
				    Vc3EchoGain--;
			      if(Vc3EchoGain <= MIN_VC3_ECHO_GAIN_LIMIT)
				    {
					    Vc3EchoGain = MIN_VC3_ECHO_GAIN_LIMIT;
				    }
            SACM_VC3_EchoMode_SetGain(Vc3EchoGain);
						break;
				}
				break;

		  case 0x08:                                 // change VC3 mode
				Vc3Mode++;
			  if(Vc3Mode > VC3_USER_DEFINE_MODE1)
				{
					Vc3Mode = VC3_SHIFT_PITCH_MODE;
				}

				switch(Vc3Mode)
				{
					case VC3_SHIFT_PITCH_MODE:
					case VC3_CONST_PITCH_MODE:
          case VC3_ECHO_MODE:
            SACM_VC3_Mode(Vc3Mode, &Vc3KernelWorkingRam);
				    SACM_VC3_ShiftPitchMode_SetPitch(Vc3ShiftPitch);
				    SACM_VC3_ConstPitchMode_SetPitch(Vc3ConstPitch);
				    SACM_VC3_EchoMode_SetGain(Vc3EchoGain);
						break;

					case VC3_VM_ROBOT_EFFECT1_MODE:
					case VC3_VM_ROBOT_EFFECT2_MODE:
					case VC3_VM_STRANGE_TONE_MODE:
					case VC3_VM_DJ_EFFECT_MODE:
					case VC3_VM_VIBRATION_MODE:
					case VC3_VM_JET_PLANE_MODE:
					case VC3_VM_DOUBLING_MODE:
					case VC3_VM_UNDERWATER_MODE:
            SACM_VC3_Mode(Vc3Mode, &Vc3VmKernelWorkingRam);
						break;

					default:
						SACM_VC3_Mode(VC3_USER_DEFINE_MODE1, NULL);
					  break;
				}
        break;

			case 0x10:                                 // "shift pitch + echo" mode
				SACM_VC3_Stop();
			  SACM_VC3_Mode(VC3_SHIFT_PITCH_MODE, &Vc3KernelWorkingRam);
			  SACM_VC3_ShiftPitchMode_SetPitch(10);
	      SACM_VC3_Mode(VC3_ECHO_MODE, &Vc3KernelWorkingRam2);
	      SACM_VC3_EchoMode_SetGain(8);
			  SACM_VC3_Mode(VC3_USER_DEFINE_MODE2, NULL);
			  SACM_VC3_Play(VC3_DAC_CH0, VC3_AUTO_RAMP_UP + VC3_AUTO_RAMP_DOWN);
			  break;

			case 0x40:                                 // volume up
				SwVolGain = ++SwVolGain >= MAX_VOL_GAIN ? MAX_VOL_GAIN : SwVolGain;
			  APP_SwVolCtrl_SetVolGain(0, SwVolGain);
				break;

      case 0x80:                                 // volume down
			  SwVolGain = --SwVolGain <= MIN_VOL_GAIN ? MIN_VOL_GAIN : SwVolGain;
			  APP_SwVolCtrl_SetVolGain(0, SwVolGain);
				break;
	  }
	}
}
